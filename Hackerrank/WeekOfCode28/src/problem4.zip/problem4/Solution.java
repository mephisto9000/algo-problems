package problem4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

public class Solution {
	
	
	String src = null;
	
	int[] tree; // kruskall
	long[] power; // kruskall
	
	long tmpPower;
	long powerIdx = -1;
	long  powerIncrement = 0;
	long  powerSum;
	
	int n;
	int m;
	
	Node[] nodes;
	
	public class Node implements Comparable
	{
		int num;
		long count;
		
		Set<Node> connections;
		
		public Node()
		{
			connections = new HashSet<Node>();
		}
		
		@Override
		public int compareTo(Object o) {
			
			Node n1 = (Node) o;
			
			if (this.count > n1.count)
				return -1;
			if (this.count < n1.count)
				return 1;
			
			return 0;
		}
	}
	
	public class Edge
	{
		int x1;
		int x2;
	}
	
	public long[] calc() throws Exception
	{
		BufferedReader br = null;
		
		if (src == null)
			br = new BufferedReader(new InputStreamReader(System.in));
		else
			br = new BufferedReader(new FileReader(src));
		
		int q = Integer.parseInt(br.readLine());
		
		long[] ans = new long[q];
		for (int i = 0; i < q; i++)
		{
			
			
			//System.out.println( " -------- ");
			String vals[] = br.readLine().split(" ");
			
			n = Integer.parseInt(vals[0]);
			m = Integer.parseInt(vals[1]);
			
			tmpPower = 0;
			powerSum = 0;
			initKruskall();
			
			
			for (int j = 0; j < m; j++)
			{
				vals = br.readLine().split(" ");
				int idx1 = Integer.parseInt(vals[0]) - 1;
				int idx2 = Integer.parseInt(vals[1]) - 1;
				
				nodes[idx1].count ++;
				nodes[idx2].count ++;
				
				nodes[idx1].connections.add(nodes[idx2]);
				nodes[idx2].connections.add(nodes[idx1]);
			}
			
			Queue<Node> queue = new PriorityQueue<Node>();
			
			for (int j = 0; j < n; j++)				
				queue.add(nodes[j]);
			
			
			
			Queue<Edge> reminderQueue = new LinkedList<Edge>();
					
			while(queue.size() > 0)
			{
				Node x = queue.poll();
				
				//System.out.println("id == "+x.num);
				
				//if (x.connections.size() > 0)
				Iterator<Node> xit = x.connections.iterator();
				while(xit.hasNext())// x.connections.size() > 0)
				{
					Node x2 = xit.next();
					
					//Node x2 = x.connections.iterator().next(); //.poll();
					
					Node removeNode = null;
					int w = 0;
					for (Node x3 : x2.connections) //.size(); z++)
					{
						//Node x3 = x2.connections.get(z);
						
						if (x3.num == x.num)
						{
							//System.out.println("removing "+x3.num + " from "+x2.num);
							//x2.connections.remove(x3);
							removeNode = x3;
						}
						w ++;
						
					}
					
					
					if(removeNode != null)
						x2.connections.remove(removeNode); 
					
					
					if (findParent(x.num) == findParent(x2.num))
					{
						Edge e = new Edge();
						e.x1 = x.num;
						e.x2 = x2.num;
						reminderQueue.add(e);
					}
					else 
					merge(x.num, x2.num);
				}
				
				x.connections.clear();
			}
			
			
			while(!reminderQueue.isEmpty())
			{
				Edge e = reminderQueue.poll();
				merge(e.x1, e.x2);
			}
			
			
			/*
			for (int j = 0; j < n; j++)
			{
				
				ans[i] += getPower(j);
			}*/
			ans[i] = tmpPower;
		}
		
		return ans;
		
		
	}
	
	private void initKruskall()
	{
		tree = new int[n];
		power = new long[n];
		
		nodes = new Node[n];
		
		for (int i = 0; i < n; i++)
		{
			tree[i] = i;
			nodes[i] = new Node();
			
			nodes[i].num = i;
			nodes[i].count = 0;
			
			
			power[i] = 0;
		}	
		
	}
	
	private int findParent(int idx)
	{
		if (tree[idx] == idx)
			return idx;
		else
		{
			int x = findParent(tree[idx]);
			tree[idx] = x;
			
			return x;
		}
	}
	
	private void merge(int x, int y)
	{
		int px = findParent(x);
		
		int py = findParent(y);
		
		//System.out.println(x + " --- " + y);
		
		
		//if (powerIdx != py && powerIdx != px)
		//	tmpPower += powerIncrement;
		
		//tmpPower -= powerIncrement;
		long powerDecrement = 0;
		if (px != py)
		{
			powerDecrement = power[px]*(power[px] + 1) + power[py] * (power[py] + 1);
			//if
			
			 double rand = Math.random() * 1;
			    if (Math.round(rand) == 1) {
			    //    ones++;
			    	power[py] += power[px] + 1;
					
					power[px] = 0;
					
					tree[px] = py;
			    } else {
			      //  zeros++;
			    	
			    	power[px] += power[py] + 1;
					
					power[py] = 0;
					
					tree[py] = px;
			    }
			    
			
			
			

			
			if (power[py] > 0)
			{
				//tmpPower += power[py] * ( power[py] + 1);
				powerIdx = py;
				powerIncrement = power[py] * ( power[py] + 1);
				
				//powerDecrement =  power[py] * ( power[py] - 1);
			}
			else
			{
				//tmpPower += power[px] * ( power[px] + 1);
				powerIdx = px;
				powerIncrement = power[px] * ( power[px] + 1);
				
				//powerDecrement = power[px] * ( power[px] - 1);
			}
			
			
								
		}
		
		else
		{
			//powerDecrement = power[px]*(power[px] + 1 ); //  + power[py] * (power[py] + 1);
			//powerIncrement =  power[px]*(power[px] + 1 );
			powerIncrement = 0;
			powerDecrement = 0;
		}
		//{
		//	tmpPower += tmpPower; // power[px] * ( power[px] + 1); //getPower(px);
		//}
		
		//tmpPower +=  powerSum +  powerIncrement ;//- powerDecrement;
		
		powerSum += powerIncrement - powerDecrement;
		
		tmpPower +=  powerSum;
		
		//if (powerIncrement > 0)
		//	powerIncrement -=  	power[px] * ( power[px] - 1);
		
		//powerIncrement += power[px] * ( power[px] + 1);
		
		//tmpPower +=     powerIncrement ;//-  powerDecrement;
		
		/*
		for (int i = 0 ; i < power.length; i++)
		{
			//if (i != powerIdx)
				//if ()
				int p = findParent(i);
					tmpPower += power[p];
		} */
		
		//tmpPower += powerIncrement;
		//System.out.println(powerIncrement == );
		 
		//System.out.println("power now == "+tmpPower + " powerInc == "+powerIncrement + " powerIdx == "+powerIdx + " powerDec == "+powerDecrement + " powerSum == "+powerSum);
		
	}

	public static void main(String[] args) throws Exception{
		
		Solution sol  = new Solution();
		
		//System.out.println( sol.calc() );
		long[] arr = sol.calc();
		for (int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}

	}

}
